# Pixel Art Package

This is the starting point for the first lab in Select Topics, 
Packaging course.

(Actually not the first lab, but whatever.)

This is the fork of Pixel Art Package created by me, Matt Baldwin,
so I could complete my Coursera Codio course on Packaging. I am 
familiar with Git and GitHub so I am probably going to do a bit more
with this than I even should.

